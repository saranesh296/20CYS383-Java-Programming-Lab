package com.amrita.jpl.cys21068.prac.fileHandeler;

public interface FileHandler {
    void uploadFile(String filePath);
    void readFile(String filePath);
}
