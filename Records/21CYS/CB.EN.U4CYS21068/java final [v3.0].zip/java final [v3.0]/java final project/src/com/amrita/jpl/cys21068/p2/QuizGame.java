package com.amrita.jpl.cys21068.p2;

public abstract class QuizGame {
    abstract void startGame();
    abstract void askQuestion();
    abstract void evaluateAnswer(String answer);
}
