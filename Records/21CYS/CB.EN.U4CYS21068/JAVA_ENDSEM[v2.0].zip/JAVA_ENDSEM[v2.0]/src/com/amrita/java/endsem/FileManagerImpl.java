package com.amrita.java.endsem;

import java.io.BufferedReader;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.util.ArrayList;

class FileManagerImpl implements FileManager {
    private ArrayList<File> files;

    public FileManagerImpl() {
        files = new ArrayList<>();
    }

    public void addFile(File file) {
        files.add(file);
        System.out.println("File added: " + file.getFileName());
    }

    public void deleteFile(String fileName) {
        File fileToDelete = null;
        for (File file : files) {
            if (file.getFileName().equals(fileName)) {
                fileToDelete = file;
                break;
            }
        }
        if (fileToDelete != null) {
            files.remove(fileToDelete);
            System.out.println("File deleted: " + fileName);
        } else {
            System.out.println("File not found: " + fileName);
        }
    }

    public void displayAllFiles() {
        System.out.println("File details:");
        for (File file : files) {
            file.displayFileDetails();
            System.out.println();
        }
    }

    public void saveToFile() {
        try (FileWriter writer = new FileWriter("files.txt")) {
            for (File file : files) {
                writer.write(file.getClass().getSimpleName() + "," + file.getFileName() + "," + file.getFileSize());
                if (file instanceof Document) {
                    writer.write("," + ((Document) file).getDocumentType());
                }
                else if (file instanceof Image) {
                    writer.write("," + ((Image) file).getResolution());
                }
                else if (file instanceof Video) {
                    writer.write("," + ((Video) file).getDuration());
                }
                writer.write("\n");
            }
            System.out.println("Files saved to disk.");
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    public void loadFromFile() {
        files.clear();
        try (BufferedReader reader = new BufferedReader(new FileReader("files.txt"))) {
            String line;
            while ((line = reader.readLine()) != null) {
                String[] fileData = line.split(",");
                String fileType = fileData[0];
                String fileName = fileData[1];
                long fileSize = Long.parseLong(fileData[2]);
                File file = null;
                if (fileType.equals("Document")) {
                    String documentType = fileData[3];
                    file = new Document(fileName, fileSize, documentType);
                }
                else if (fileType.equals("Image")) {
                    String resolution = fileData[3];
                    file = new Image(fileName, fileSize, resolution);
                }
                else if (fileType.equals("Video")) {
                    int duration = Integer.parseInt(fileData[3]);
                    file = new Video(fileName, fileSize, duration);
                }
                if (file != null) {
                    files.add(file);
                }
            }
            System.out.println("Files loaded from disk.");
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    public ArrayList<File> getFiles() {
        return files;
    }
}
