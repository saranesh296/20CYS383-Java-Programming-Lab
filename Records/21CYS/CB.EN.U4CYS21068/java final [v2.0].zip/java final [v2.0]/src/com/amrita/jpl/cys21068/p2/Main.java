package com.amrita.jpl.cys21068.p2;
class Main {
    public static void main(String[] args) {
        QuizGameServer server = new QuizGameServer();
        QuizGameClient client = new QuizGameClient(server);

        client.startGame();
    }
}
