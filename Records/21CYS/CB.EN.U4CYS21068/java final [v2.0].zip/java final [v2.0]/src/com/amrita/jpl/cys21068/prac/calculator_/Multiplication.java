package com.amrita.jpl.cys21068.prac.calculator_;

class Multiplication extends Calculation {
    /**
     * Performs multiplication of two numbers.
     */

    double calculate(double operand1, double operand2) {
        return operand1 * operand2;
    }
}