package com.amrita.jpl.cys21068.p1;

import java.util.Scanner;
/**
 * A program that provides various operations based on user's choice.
 */

public class p1 {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        int choice = 2;

        cases cases = new cases();

        while (choice != 0) {
            System.out.println("MENU");
            System.out.println("1. Reverse of a number (reverse_num)");
            System.out.println("2. Largest of three numbers (large3num)");
            System.out.println("3. Perfect Square Check (perfect_square_check)");
            System.out.println("4. Prime Test (prime_test)");
            System.out.println("5. Exit");

            System.out.print("Enter your choice: ");
            choice = scanner.nextInt();

            switch (choice) {
                case 1:
                    System.out.print("Enter a number: ");
                    int num = scanner.nextInt();
                    int reverse = cases.reverseNum(num);
                    System.out.println("Reversed num: " + reverse);
                    break;
                case 2 :
                    System.out.print("Enter three nums one by one: ");
                    int num1 = scanner.nextInt();
                    int num2 = scanner.nextInt();
                    int num3 = scanner.nextInt();
                    int largest = cases.large3num(num1, num2, num3);
                    System.out.println("Largest num: " + largest);
                    break;
                case 3:
                    System.out.print("Enter a number: ");
                    int n = scanner.nextInt();
                    cases.perfectSquareCheck(n);
                    break;
                case 4:
                    System.out.print("Enter a number: ");
                    int x = scanner.nextInt();
                   cases.primeTest(x);
                    break;
                case 5 :
                    System.out.println("Exiting...");
                    break;
                default:
                    System.out.println("Invalid choice!");
                    break;
            }
        }
    }
}
/**
 * A class that contains methods to perform various operations.
 */
class cases {
/**
 * Reverses the digits of a given number.
 */
    public int reverseNum(int num) {
        int reverse = 0;
        while (num != 0) {
            reverse = reverse * 10 + num % 10;
            num /= 10;
        }
        return reverse;
    }
/**
 * Finds the largest of three numbers.
 */
    public int large3num(int a, int b, int c) {
        int largest = a;
        if (b > largest) {
            largest = b;
        }
        if (c > largest) {
            largest = c;
        }
        return largest;
    }
/**
 * Checks if a number is a perfect square.
 */

    public void perfectSquareCheck(int n) {
        int root = (int) Math.sqrt(n);
        if (root * root == n) {
            System.out.println(n + " is a perfect square");
        }
        else {
            System.out.println(n + " is not a perfect square");
        }
    }
/**
 * Checks if a number is a prime number
 */
    public void primeTest(int x) {
        int a=1;
        if (x < 2) {
            a=0;
        }
        else {
            for (int i = 2; i <= Math.sqrt(x); i++) {
                if (x % i == 0) {
                    a=0;
                    break;
                }
            }
        }
        if (a==1) {
            System.out.println(x + " is a prime number");
        }
        else {
            System.out.println(x + " is not a prime number");
        }
    }
}
