package com.amrita.java.endsem;

class Document extends File {
    private String documentType;

    public Document(String fileName, long fileSize, String documentType) {
        super(fileName, fileSize);
        this.documentType = documentType;
    }

    public String getDocumentType() {
        return documentType;
    }

    public void setDocumentType(String documentType) {
        this.documentType = documentType;
    }

    public void displayFileDetails() {
        System.out.println("Document Name: " + getFileName());
        System.out.println("File Size: " + getFileSize());
        System.out.println("Document Type: " + getDocumentType());
    }
}