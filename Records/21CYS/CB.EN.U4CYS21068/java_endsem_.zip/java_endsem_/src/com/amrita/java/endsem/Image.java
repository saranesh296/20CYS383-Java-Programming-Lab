package com.amrita.java.endsem;

class Image extends File {
    private String resolution;

    public Image(String fileName, long fileSize, String resolution) {
        super(fileName, fileSize);
        this.resolution = resolution;
    }

    public String getResolution() {
        return resolution;
    }

    public void setResolution(String resolution) {
        this.resolution = resolution;
    }

    public void displayFileDetails() {
        System.out.println("Image Name: " + getFileName());
        System.out.println("File Size: " + getFileSize());
        System.out.println("Resolution: " + getResolution());
    }
}