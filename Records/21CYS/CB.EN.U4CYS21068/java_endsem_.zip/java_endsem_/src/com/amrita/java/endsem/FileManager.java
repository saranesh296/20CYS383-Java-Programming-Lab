package com.amrita.java.endsem;

import java.util.ArrayList;

interface FileManager {
    void addFile(File file);
    void deleteFile(String fileName);
    void displayAllFiles();
    void saveToFile();
    void loadFromFile();
    ArrayList<File> getFiles();
}