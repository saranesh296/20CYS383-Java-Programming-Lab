package com.amrita.java.endsem;

class Video extends File {
    private int duration;

    public Video(String fileName, long fileSize, int duration) {
        super(fileName, fileSize);
        this.duration = duration;
    }

    public int getDuration() {
        return duration;
    }

    public void setDuration(int duration) {
        this.duration = duration;
    }

    public void displayFileDetails() {
        System.out.println("Video Name: " + getFileName());
        System.out.println("File Size: " + getFileSize());
        System.out.println("Duration: " + getDuration());
    }
}
