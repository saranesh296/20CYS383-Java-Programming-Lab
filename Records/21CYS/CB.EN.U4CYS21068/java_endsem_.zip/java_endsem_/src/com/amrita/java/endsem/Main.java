package com.amrita.java.endsem;

import java.util.Scanner;

public class Main {
    public static void main(String[] args) {
        FileManager fileManager = new FileManagerImpl();
        Scanner scanner = new Scanner(System.in);

        boolean a=true;
        while (a) {
            System.out.println("1. Add file\n" +
                    "2. Delete file\n" +
                    "3. Display files\n" +
                    "4. Save files\n"+
                    "5. Load files\n" +
                    "6. Exit\n" +
                    "Enter your choice: ");

            int choice = scanner.nextInt();
            scanner.nextLine();

            switch (choice) {
                case 1:
                    System.out.println("Enter file type\n" +
                            "1. Document\n" +
                            "2. Image\n" +
                            "3. Video");
                    int fileType = scanner.nextInt();
                    scanner.nextLine();

                    System.out.print("Enter the file name: ");
                    String fileName = scanner.nextLine();

                    System.out.print("Enter the file size: ");
                    long fileSize = scanner.nextLong();

                    switch (fileType) {
                        case 1:
                            System.out.print("type: ");
                            String documentType = scanner.nextLine();
                            File documentFile = new Document(fileName, fileSize, documentType);
                            fileManager.addFile(documentFile);
                            System.out.println("Document added");
                            break;
                        case 2:
                            System.out.print("resolution: ");
                            String resolution = scanner.nextLine();
                            File imageFile = new Image(fileName, fileSize, resolution);
                            fileManager.addFile(imageFile);
                            System.out.println("Image added");
                            break;
                        case 3:
                            System.out.print("duration: ");
                            int duration = scanner.nextInt();
                            File videoFile = new Video(fileName, fileSize, duration);
                            fileManager.addFile(videoFile);
                            System.out.println("Video added");
                            break;
                        default:
                            System.out.println("Enter a Valid Input");
                            break;
                    }
                    break;
                case 2:
                    System.out.print("Enter the file name to delete: ");
                    String fileToDelete = scanner.nextLine();
                    fileManager.deleteFile(fileToDelete);
                    break;
                case 3:
                    fileManager.displayAllFiles();
                    break;
                case 4:
                    fileManager.saveToFile();
                    System.out.println("Files saved");
                    break;
                case 5:
                    fileManager.loadFromFile();
                    System.out.println("Files loaded");
                    break;
                case 6:
                    a=false;
                    System.out.println("Exiting...");
                    break;
                default:
                    System.out.println("Invalid choice!");
                    break;
            }

            System.out.println();
        }

        scanner.close();
    }
}
